<?php
    require_once '../funcoes/init.php';
    $id = isset($_POST['id']) ? $_POST['id'] : null;
    $nome = isset($_POST['nome']) ? $_POST['nome'] : null;
    $dataNascimento = isset($_POST['dataNascimento']) ? $_POST['dataNascimento'] : null;
    $raca = isset($_POST['raca']) ? $_POST['raca'] : null;
    if (empty($nome) || empty($dataNascimento) || empty($raca))
    {
        echo "Volte e preencha todos os campos";
        exit;
    }
    $PDO = db_connect();
    $sql = "UPDATE myPets SET nomePet = :nome, dataNascimento = :dataNascimento, raca = :raca WHERE id = :id";
    $stmt = $PDO->prepare($sql);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':dataNascimento', $dataNascimento);
    $stmt->bindParam(':raca', $raca);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    if ($stmt->execute())
    {
        header('Location: ../html/msgSucesso.html');
    }
    else
    {
        echo "Erro ao alterar!";
        print_r($stmt->errorInfo());
    }
?>